<form action="api/PaymentControllerBoleto.php" name='formCard' id='formCard' method="post">
    <input type="hidden" name="valor"value='<?php echo $_SESSION['valor'] ?>'>
    <?php $ajuste = ($_SESSION['valor']+($_SESSION['valor']*3.99)/100);
    $soma =  round($ajuste , 2, PHP_ROUND_HALF_DOWN);
    
echo "<pre>Lembramos que cobraremos uma taxa de 3,99% sobre o valor</pre>";
echo "<pre>O seu novo valor ficou em R$ ".$soma."</pre>";?>
    
    <div class="mb-3">
        <input type="submit" value="Comprar" class='btn btn-primary'>
    </div>
</form>
<?php
             
    //$extenso = $extenso->converter($valor);
   // echo $extenso.'<br>'.$valor;
                    
?>