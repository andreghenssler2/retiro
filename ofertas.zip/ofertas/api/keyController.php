<?php

class keyController{
    public static function getpublic(){
        $token = $_SESSION['token'] ;
        $data ['type'] = "card";
        $curl = curl_init('https://sandbox.api.pagseguro.com/public-keys/');
        $url_token_site_publick = $_SESSION['url_token_site_publick'];
            $curl = curl_init($url_token_site_publick);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
            'content-type: application/json',
            'Authorization: '.$token
        ));
        curl_setopt($curl, CURLOPT_POST,true);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER,true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,false);
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));

        $retorno = curl_exec($curl);
        curl_close($curl);
        return json_decode($retorno)->public_key; 
    }
}


