<?php
    
    $status = false;
    if($status==false){
        define('url','https://sandbox.api.pagseguro.com/');
        define('token','64C09E1578824C8C8A197BC2F2F4AE0E');

    }else{
        define('url','https://api.pagseguro.com');
        define('token','64C09E1578824C8C8A197BC2F2F4AE0E');
    }
    $token = token;
    $_SESSION['url_token_site_publick'] ='https://sandbox.api.pagseguro.com/public-keys/';
    $_SESSION['url_token_site'] = url;
    $_SESSION['token'] = $token;
    require 'keyController.php';
    $data_hoje = date('Y-m-d'); // Data atual
    $data_hoje_mdias = date('Y-m-d', strtotime($data_hoje. ' + 3 days')); // Cria data no formato normar com o agrecimo de 3 dias apartir da data atual; formato Y-m-Y
    $_SESSION['data_hoje_mdias'] = $data_hoje_mdias ; // 

    # Expiração do PIX
    $pix_ano = date('Y');
    $pix_mes = date('m');
    $pix_dia = date('d');
    $pix_hora = date('h')+2;
    $pix_min = date('m');
    $pix_segu = date('s');
    $data_hoje_pix =  date(DATE_ATOM, mktime($pix_hora, $pix_min, $pix_segu, $pix_dia, $pix_mes, $pix_ano));

    function sanitizeString($string) {

        // matriz de entrada
        $what = array( 'ä','ã','à','á','â','ê','ë','è','é','ï','ì','í','ö','õ','ò','ó','ô','ü','ù','ú','û','À','Á','É','Í','Ó','Ú','ñ','Ñ','ç','Ç',' ','-','(',')',',',';',':','|','!','"','#','$','%','&','/','=','?','~','^','>','<','ª','º','.' );
    
        // matriz de saída
        $by   = array( 'a','a','a','a','a','e','e','e','e','i','i','i','o','o','o','o','o','u','u','u','u','A','A','E','I','O','U','n','n','c','C','_','_','_','_','_','_','_','_','_','_','_','_','_','_','_','_','_','_','_','_','_','_','_' );
    
        // devolver a string
        return str_replace($what, $by, $string);
    }
    function adicionaString($string) {

        // matriz de entrada
        $what = array( 'ä','ã','à','á','â','ê','ë','è','é','ï','ì','í','ö','õ','ò','ó','ô','ü','ù','ú','û','À','Á','É','Í','Ó','Ú','ñ','Ñ','ç','Ç',' ','-','(',')',',',';',':','|','!','"','#','$','%','&','/','=','?','~','^','>','<','ª','º','.' );
    
        // matriz de saída
        $by   = array( 'a','a','a','a','a','e','e','e','e','i','i','i','o','o','o','o','o','u','u','u','u','A','A','E','I','O','U','n','n','c','C','_','_','_','_','_','_','_','_','_','_','_','_','_','_','_','_','_','_','_','_','_','_','_','.' );
    
        // devolver a string
        return str_replace($what, $by, $string);
    }