<?php
    $ajuste = ($_SESSION['valor']+($_SESSION['valor']*4.79)/100);
    $valor =  round($ajuste , 2, PHP_ROUND_HALF_DOWN);
?>
<form action="api/PayController.php" name='formCard' id='formCard' method="post">
    <input type="hidden" name="publicKey" id='publicKey' value='<?php echo $keypublick::getpublic(); ?>'>            <input type="hidden" name="encriptedCard" id='encriptedCard'>
    <input type="hidden" name="valor"value='<?php echo $valor ?>'>
    <div class="mb-3">
        <label for="carNumber" class="form-label">Número Cartão</label>
        <input type="text" class="form-control" name="carNumber" id="carNumber" placeholder=""  maxlength='16'>
    </div>
    <div class="mb-3">
        <label for="cardHolder" class="form-label">Nome: </label>
        <input type="text" class="form-control" id="cardHolder" name="cardHolder" placeholder=""  maxlength='16'>
    </div>
    <div class="mb-3">
        <label for="cardMonth" class="form-label">Mês</label>
        <input type="text" class="form-control" id="cardMonth" name="cardMonth" placeholder=""  maxlength='2'>
    </div>
    <div class="mb-3">
        <label for="cardYear" class="form-label">Anos</label>
        <input type="text" class="form-control" id="cardYear" name="cardYear" placeholder=""  maxlength='4'>
    </div>
    <div class="mb-3">
        <label for="cardCvv" class="form-label">CVV</label>
        <input type="text" class="form-control" id="cardCvv" name="cardCvv" placeholder=""  maxlength='4'>
    </div>
    <div class="mb-3">
        <input type="submit" value="Salvar" class='btn btn-primary'>
    </div>
</form>
<?php
             
    $extenso = $extenso->converter($valor);
    echo $extenso.'<br>'.$valor;
                    
?>