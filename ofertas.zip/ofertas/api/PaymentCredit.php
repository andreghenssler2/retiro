<?php
    include "PaymentController.php";
    define('url_credit',url."/charges/");
    // Campos a ser enviado
    $data['"reference_id'] = "ex-test-1-credit";
    $data["description"] = 'Testando Credito';
    $data["amount"] =[
        "value"=> 500,
        "currency"=> "BRL"
    ];
    $data["notification_urls"] = [
        "https://meusite.com/notificacoes"
    ];
    $data["payment_method"]= [
        "type"=> "CREDIT_CARD",
        "installments"=> 1,
        "capture"=> true,
        "card"=> [
          "number"=> "4111111111111111",
          "exp_month"=> "12",
          "exp_year"=> "2026",
          "security_code"=> "123",
          "holder"=> [
            "name"=> "Jose da Silva"
          ],
          "store"=> true
        ]
    ];
        $data = json_encode($data);
        echo $data;
?>

<!--
curl --location --request POST 'https=> //sandbox.api.pagseguro.com/orders' \
--header 'Authorization: Bearer [ [TOKEN ]]' \
--header 'Content-Type: application/json' \
--data-raw '[
  "reference_id": "ex-00001",
  "customer": [
    "name": "Jose da Silva",
    "email": "email@test.com",
    "tax_id": "12345678909",
    "phones": [
      [
        "country": "55",
        "area": "11",
        "number": "999999999",
        "type": "MOBILE"
      ]
    ]
  ],
  "items": [
    [
      "reference_id": "referencia do item",
      "name": "nome do item",
      "quantity": 1,
      "unit_amount": 500
    ]
  ],
  "shipping": [
    "address": [
      "street": "Avenida Brigadeiro Faria Lima",
      "number": "1384",
      "complement": "apto 12",
      "locality": "Pinheiros",
      "city": "São Paulo",
      "region_code": "SP",
      "country": "BRA",
      "postal_code": "01452002"
    ]
  ],
  ,
  "charges": [
    [
      "reference_id": "referencia da cobranca",
      "description": "descricao da cobranca",
      "amount": {
        "value": 500,
        "currency": "BRL"
      ],
      "payment_method": {
        "type": "CREDIT_CARD",
        "installments": 1,
        "capture": true,
        "card": {
          "number": "4111111111111111",
          "exp_month": "12",
          "exp_year": "2026",
          "security_code": "123",
          "holder": {
            "name": "Jose da Silva"
          ],
          "store": false
        ]
      ]
    ]
  ]
]'