$(document).ready(function(){
    if(document.querySelector("#formCard")){
        let  formCard = document.querySelector("#formCard");
        formCard.addEventListener('submit',e=>{
            e.preventDefault();
            let card = PagSeguro.encryptCard({
                publicKey: document.querySelector("#publicKey").value,
                holder: document.querySelector("#cardHolder").value,
                number: document.querySelector("#carNumber").value,
                expMonth: document.querySelector("#cardMonth").value,
                expYear: document.querySelector("#cardYear").value,
                securityCode: document.querySelector("#cardCvv").value
            });
            let  encrypted = card.encryptedCard;
            
            console.log(encrypted);
            document.querySelector('#encriptedCard').value = encrypted;
            formCard.submit();
        });
    }
});