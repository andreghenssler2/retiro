<?php
    #include 'api/PaymentController.php';
    $token = $_SESSION['token'] ;
    $url_token_site = $_SESSION['url_token_site_publick'].'orders';
    $ajuste = ($_SESSION['valor']+($_SESSION['valor']*1.99)/100);
    $soma =  round($ajuste , 2, PHP_ROUND_HALF_DOWN);

    $valor = sanitizeString($soma);

    echo "<pre>Lembramos que cobraremos uma taxa de 1% sobre o valor</pre>";
    echo "<pre>O seu novo valor ficou em R$ ".$soma."</pre>";

    $data['reference_id'] = "ex-00001";
    $data["customer"] = [
        "name"=> "Jose da Silva",
            "email"=> "email@test.com",
            "tax_id"=> "12345678909",
            "phones"=> [
            [
                "country"=> "55",
                "area"=> "11",
                "number"=> "999999999",
                "type"=> "MOBILE"
            ]
        ]
    ];
    $data["items"] = [
        [
            "name"=> "nome do item",
            "quantity"=> 1,
            "unit_amount"=> $valor
        ]
    ];
    
    $data["qr_codes"] = [
        [
            "amount"=> [
                "value"=> $valor
            ],
            "expiration_date"=> $data_hoje_pix,
        ]
    ];
    $data["shipping"] = [
    "address"=> [
        "street"=> "Avenida Brigadeiro Faria Lima",
            "number"=> "1384",
            "complement"=> "apto 12",
            "locality"=> "Pinheiros",
            "city"=> "São Paulo",
            "region_code"=> "SP",
            "country"=> "BRA",
            "postal_code"=> "01452002"
        ]
    ];
$data = json_encode($data);

#Requisição ao Pagseguro
$curl = curl_init($url_token_site);
curl_setopt($curl,CURLOPT_POST,true);
curl_setopt($curl,CURLOPT_HTTPHEADER,array(
    'Authorization:'.$token,
    'Content-Type: application/json'
));
curl_setopt($curl,CURLOPT_RETURNTRANSFER,true);
curl_setopt($curl,CURLOPT_POSTFIELDS,$data);
curl_setopt($curl,CURLOPT_SSL_VERIFYPEER,false);
$ress = curl_exec($curl);
$ress = json_decode($ress);
//echo "<pre>",print_r($ress),"</pre>";
echo "<img src='".$ress->qr_codes[0]->links[0]->href."' alt='Qrcode Pix'>";
echo "<p> Copia e cola<br>".$ress->qr_codes[0]->text."</p>";
            