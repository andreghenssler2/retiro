<?php
    include 'PaymentController.php';
    $token = $_SESSION['token'] ;
    $url_token_site = $_SESSION['url_token_site'].'charges';
    $ajuste = ($_POST['valor']+($_POST['valor']*3.99)/100);
    $soma =  round($ajuste , 0, PHP_ROUND_HALF_DOWN);
    $valor = sanitizeString($soma);



    $data_hoje_medias =  $_SESSION['data_hoje_mdias'];
    $data['reference_id'] = "ex-00001";
    $data['description'] = "Motivo do pagamento";
    $data['amount'] = [
        "value" => $valor,
        "currency" => "BRL"
    ];
    $data['payment_method'] = [
        "type"=> "BOLETO",
        "boleto"=> [
            "due_date"=> $data_hoje_medias,//"2024-12-31",
            "instruction_lines"=> [
                "line_1"=> "Compra de  ",
                "line_2"=> "h"
            ],
            "holder"=> [
                "name"=> "Jose da Silva",
            "tax_id"=> "22222222222",
            "email"=> "jose@email.com",
            "address"=> [
                "street"=> "Avenida Brigadeiro Faria Lima",
                "number"=> "1384",
                "locality"=> "Pinheiros",
                "city"=> "Sao Paulo",
                "region"=> "Sao Paulo",
                "region_code"=> "SP",
                "country"=> "Brasil",
                "postal_code"=> "01452002"
            ]
        ]
        ]
    ];
    $data["notification_urls"] = [
        "https://yourserver.com/nas_ecommerce/277be731-3b7c-4dac-8c4e-4c3f4a1fdc46/"
    ];
    $data = json_encode($data);

    #Requisição ao Pagseguro
    $curl = curl_init($url_token_site);
    curl_setopt($curl,CURLOPT_POST,true);
    curl_setopt($curl,CURLOPT_HTTPHEADER,array(
        'Authorization:'.$token,
        'Content-Type: application/json'
    ));
    curl_setopt($curl,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($curl,CURLOPT_POSTFIELDS,$data);
    curl_setopt($curl,CURLOPT_SSL_VERIFYPEER,false);
    $ress = curl_exec($curl);
    $ress = json_decode($ress);
    header(".ocation: ".$ress->links[0]->href."");
?>
