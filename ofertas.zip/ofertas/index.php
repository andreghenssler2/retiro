<?php 

require 'pagament.php';